import React from 'react';
import { Tabs, AppBar, Grid } from '@material-ui/core';
import LinkTab from './LinkTab';
import TabPageContainer from '../../layouts/TabPageContainer';

const Header = () => {
	const [value, setValue] = React.useState(0);

	function handleChange(event: React.ChangeEvent<{}>, newValue: number) {
		setValue(newValue);
	}
	return (
		<div>
			<AppBar position="static">
				<Grid container direction="row" justify="center" alignItems="center">
					<Grid item xs={6}>
						<Tabs variant="fullWidth" value={value} onChange={handleChange}>
							<LinkTab label="Page One" href="/drafts" />
							<LinkTab label="Page Two" href="/trash" />
							<LinkTab label="Page Three" href="/spam" />
						</Tabs>
					</Grid>
				</Grid>
			</AppBar>
			{value === 0 && <TabPageContainer>Page One</TabPageContainer>}
			{value === 1 && <TabPageContainer>Page Two</TabPageContainer>}
			{value === 2 && <TabPageContainer>Page Three</TabPageContainer>}
		</div>
	);
};

export default Header;
