import React from 'react';
import { Tab } from '@material-ui/core';

interface LinkTabProps {
	label?: string;
	href?: string;
}

const LinkTab = (props: LinkTabProps) => {
	return (
		<Tab
			component="a"
			onClick={(event: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => {
				event.preventDefault();
			}}
			{...props}
		/>
	);
};

export default LinkTab;
