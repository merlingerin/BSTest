import React, { useState } from 'react';
import _, { map } from 'lodash';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';

interface ISelectProps {
	name: string;
	id: string;
	options: [];
}

const SelectCity: React.FC<ISelectProps> = ({ name, id, options }) => {
	const [option, setOption] = useState({
		value: 0,
		name: '',
	});

	function _handleChange(event: React.ChangeEvent<{ name?: string; value: unknown }>) {
		const name = _.get(event, 'target.name', '');
		const value = _.get(event, 'target.value', null);

		setOption({ name: name, value: value });
	}

	return (
		<div>
			<div>
				<InputLabel htmlFor="demo-controlled-open-select">{name.toUpperCase()}</InputLabel>
				<Select
					value={option.value}
					onChange={_handleChange}
					inputProps={{
						name: name,
						id: 'demo-controlled-open-select',
					}}
				>
					<MenuItem value="">
						<em>None</em>
					</MenuItem>
					{map(options, (option: { Id: number; Name: string }) => (
						<MenuItem key={option.Id} value={option.Id}>
							<em>{option.Name}</em>
						</MenuItem>
					))}
				</Select>
				{/* <select name={name} id={id || name}>
          <option value="" defaultChecked></option>
          {map(options, (option: { Id: number; Name: string }) => (
            <option key={option.Id} value={option.Id}>
              {option.Name}
            </option>
          ))}
        </select> */}
			</div>
		</div>
	);
};

export default SelectCity;
