import React from 'react';
import { Container } from '@material-ui/core';

const DefaultAppLayout: React.FC = ({ children }) => {
	return <Container fixed>{children}</Container>;
};

export default DefaultAppLayout;
