import React from 'react';
import Typography from '@material-ui/core/Typography';

interface TabPageContainerProps {
	children?: React.ReactNode;
}

const TabPageContainer = (props: TabPageContainerProps) => {
	return (
		<Typography component="div" style={{ padding: 24 }}>
			{props.children}
		</Typography>
	);
};

export default TabPageContainer;
