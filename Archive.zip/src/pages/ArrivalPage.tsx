import React from 'react';

export const ArrivalPage = () => {
	return <div>ArrivalPage</div>;
};

export default ArrivalPage;
