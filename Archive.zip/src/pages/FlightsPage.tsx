import React from 'react';

export const FlightsPage = () => {
	return <div>FlightsPage</div>;
};

export default FlightsPage;
