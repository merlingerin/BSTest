import React from 'react';

export const RoomingPage = () => {
	return <div>RoomingPage</div>;
};

export default RoomingPage;
