import React from 'react';

export const TransferPage = () => {
	return <div>TransferPage</div>;
};

export default TransferPage;
