import React from 'react';
import { Switch, Route } from 'react-router-dom';
import { ArrivalPage, FlightsPage, RoomingPage, TransferPage } from '../pages';

const RootRoute = () => {
	return (
		<Switch>
			<Route path="/" exact component={FlightsPage} />
			<Route path="/arrivals" component={ArrivalPage} />
			<Route path="/rooming" component={RoomingPage} />
			<Route path="/transfer" component={TransferPage} />
		</Switch>
	);
};

export default RootRoute;
